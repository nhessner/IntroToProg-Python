#-------------------------------------------------#
# Title: "Working with Functions and Classes"
# Code Based on "Working with Dictionaries" by Randal Root
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   NHessner, 02/19/2018, Put Script into Functions and Class

#-------------------------------------------------#
#-- Data --#
# objFileName: Object containing file path for ToDo.txt, which data will be retrieved from and written to.
# lstTable: Variable for storing dictionary data pulled from ToDo.txt


#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
#When the program starts, load any existing data from ToDo.txt into a Python Dictionary

#Create a class to capture all of the functions.
class ToDoOps:

    # Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
    def LoadText():
        objfile = open(objFileName, "r")
        for line in objfile:
            strData = line.split(",") #separate data into individual elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)

    # Display all todo items to user
    # Function for menu item 1
    def CurrentTable():
        print("******Current To-Do List******" + "\n")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("\n" + "******************************")

    # Allow user to input new item
    # Function for menu item 2
    def NewItem():
        strTask = str(input("What is the task? -")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)

    # Allow user to remove item from list
    # Function for menu item 3
    def RemoveItem():
        strKeyToRemove = input("Which task would you like to remove from the list? - ")
        binItemRemoved = False
        intRowNumber = 0
        while(intRowNumber < len(lstTable)):
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):
                del lstTable[intRowNumber]
                binItemRemoved = True
            intRowNumber += 1 #advance row number
        # inform user whether or not the removal was successful
        if binItemRemoved == True:
            print("Task has been removed.")
        else:
            print("Task could not be found.")

    # Allow user to save data to Todo.txt file
    # Menu option 4
    def SaveList():
        if("y" == str(input("Would you like to save changes to the file? (y/n)")).strip().lower()):
            objFile = open(objFileName, "w")
            for row in lstTable:
                rowTask = (row["Task"]).strip("[]")
                rowPriority = (row["Priority"]).strip("[]")
                writeRow = str(rowTask) + "," + str(rowPriority) + "\n"
                objFile.write(writeRow)
            objFile.close()
            input("Data has been saved. Press [Enter] key to return to menu.")
        else:
            input("Changes have not been saved. Press [Enter] key to return to menu.")

    # Close the program
    # Menu option 5
    def ExitProgram():
        exit()

    # Display a menu of choices to the user
    def DisplayMenu():
        print("""
        To-Do List Menu
        1.) Display current list.
        2.) Add a new item.
        3.) Remove an item.
        4.) Save list to file.
        5.) Exit Program.
        """)

    #Function that allows user to choose operation to perform for the to-do list.
    def MenuSelect():
        strChoice = str(input("Please press the number of the menu option you would like to perform [1 to 5]."))
        if strChoice == "1":
            ToDoOps.CurrentTable()
        elif strChoice == "2":
            ToDoOps.NewItem()
        elif strChoice == "3":
            ToDoOps.RemoveItem()
        elif strChoice == "4":
            ToDoOps.SaveList()
        elif strChoice == "5":
            ToDoOps.ExitProgram()
        else:
            input("Invalid selection. Press [enter] to continue.")

#Main Body of Code

#Define Variables
objFileName = "C:\_PythonClass\Todo.txt"
lstTable = []

#Load the existing ToDo.txt dictionary
ToDoOps.LoadText()

#Open the menu and run selections.
while True:
    ToDoOps.DisplayMenu()
    ToDoOps.MenuSelect()



